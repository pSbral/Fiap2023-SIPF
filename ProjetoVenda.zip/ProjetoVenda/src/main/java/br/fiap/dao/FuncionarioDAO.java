package br.fiap.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class FuncionarioDAO extends DAO {

	// método para inserir um funcionário na base de dados
	/*public void inserir(Funcionario funcionario) {
		sql = "insert into java_funcionario values(funcionario_sequence.nextval, ?, ?, ?)";

		try (Connection connection = conexao.conectar()) {
			ps = connection.prepareStatement(sql);
			ps.setString(1, funcionario.getNome());
			ps.setDouble(2, funcionario.getSalario());
			ps.setInt(3, funcionario.getCargo().getId());
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			System.out.println("Erro ao cadastrar funcionário");
		}
	}*/

	// método para retornar a lista de funcionários
	
}
