package br.fiap.entidade;

public interface Comissao {
	public double calcularComissao(double valor);
}
