package br.fiap.dao;

import java.sql.Connection;
import java.sql.SQLException;


public class VendaDAO extends DAO {
	
	// método para inserir uma venda na tabela java_venda
	/*public void inserir(Venda venda) {
		sql = "insert into java_venda values(venda_sequence.nextval, ?, ?, ?)";
		
		try (Connection connection = conexao.conectar()) {
			ps = connection.prepareStatement(sql);
			ps.setInt(1, venda.getFuncionario().getId());
			ps.setDouble(2, venda.getValor());
			ps.setDouble(3, venda.getValor());
			ps.execute();
			ps.close();
			connection.close();
		} catch (SQLException e) {
			System.out.println("Erro ao inserir vendas");
		}
	}*/
	
	// método para listar todos os funcionários e a soma de suas vendas
	
	
}
